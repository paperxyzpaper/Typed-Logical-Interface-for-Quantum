import numpy as np

def classical_min_queries(values):
    best_idx = 0
    queries = 0
    for i in range(1, len(values)):
        queries += 1
        if values[i] < values[best_idx]:
            best_idx = i
    return best_idx, queries

def quantum_query_estimate(n):
    return int(np.ceil(np.sqrt(n)))

def main():
    rng = np.random.default_rng(5)
    values = rng.normal(size=64)
    idx, classical_q = classical_min_queries(values)
    quantum_q = quantum_query_estimate(len(values))

    print("Backend illustration: candidate-search query scaling")
    print(f"number of candidates   = {len(values)}")
    print(f"classical comparisons  = {classical_q}")
    print(f'quantum query estimate = O(sqrt(N)) ~ {quantum_q}')
    print(f"argmin index           = {idx}")
    print(f"minimum value          = {values[idx]:.6f}")

if __name__ == "__main__":
    main()
