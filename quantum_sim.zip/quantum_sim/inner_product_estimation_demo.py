import numpy as np

def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n != 0 else v

def estimated_inner_product(x, y, shots=2000, rng=None):
    if rng is None:
        rng = np.random.default_rng(0)
    x = normalize(x)
    y = normalize(y)
    true_ip = float(np.dot(x, y))
    p = (1.0 + true_ip) / 2.0
    samples = rng.binomial(1, p, size=shots)
    p_hat = float(samples.mean())
    return 2 * p_hat - 1, true_ip

def main():
    rng = np.random.default_rng(21)
    x = np.array([1.0, 2.0, -1.0, 0.5])
    y = np.array([0.3, -0.1, 0.9, 1.7])

    ip_hat, ip_true = estimated_inner_product(x, y, shots=4000, rng=rng)
    norm_term = np.linalg.norm(x)**2 + np.linalg.norm(y)**2
    sq_dist_true = np.linalg.norm(x - y)**2
    sq_dist_hat = norm_term - 2 * (ip_hat * np.linalg.norm(x) * np.linalg.norm(y))

    print("Backend illustration: inner-product-based distance estimate")
    print(f"true inner product (normalized) = {ip_true:.6f}")
    print(f"estimated inner product         = {ip_hat:.6f}")
    print(f"true squared distance          = {sq_dist_true:.6f}")
    print(f"estimated squared distance     = {sq_dist_hat:.6f}")

if __name__ == "__main__":
    main()
