from pathlib import Path
import numpy as np

def true_distance(x, y):
    return float(np.linalg.norm(x - y))

def noisy_backend_distance(x, y, rng, eps=0.05):
    d = true_distance(x, y)
    noise = rng.uniform(-eps, eps)
    return d + noise

def main():
    rng = np.random.default_rng(12)
    pts = {
        "a": np.array([0.0, 0.0]),
        "b": np.array([1.0, 0.4]),
        "c": np.array([0.3, 1.2]),
    }

    print("Backend illustration: bounded-error distance estimates")
    for u in pts:
        for v in pts:
            if u < v:
                d_true = true_distance(pts[u], pts[v])
                d_hat = noisy_backend_distance(pts[u], pts[v], rng)
                print(f"{u}-{v}: true={d_true:.4f}, estimated={d_hat:.4f}, abs.err={abs(d_true-d_hat):.4f}")

if __name__ == "__main__":
    main()
