# Quantum simulation backend illustration

This directory contains small backend-oriented demonstrations.

## Scripts
- `backend_demo.py` — bounded-error distance backend
- `inner_product_estimation_demo.py` — inner-product-based distance illustration
- `minimum_finding_toy_demo.py` — query-scaling illustration for candidate search

## Role
This directory is **backend illustration**. It is not the proof artifact and it is not presented as a full
quantum k-center implementation.
