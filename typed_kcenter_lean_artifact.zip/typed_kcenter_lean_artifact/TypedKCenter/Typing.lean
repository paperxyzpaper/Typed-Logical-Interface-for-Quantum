import TypedKCenter.Syntax

namespace TypedKCenter

inductive HasTypeE : Ctx → Expr → Ty → Prop where
  | var    : Ctx.lookup Γ x = some τ → HasTypeE Γ (.var x) τ
  | ptLit  : HasTypeE Γ (.ptLit p) .pt
  | realLit : HasTypeE Γ (.realLit z) .real
  | natLit : HasTypeE Γ (.natLit n) .nat
  | boolLit : HasTypeE Γ (.boolLit b) .bool
  | emptySet : HasTypeE Γ .emptySet .setPt
  | setLit : (∀ e ∈ xs, HasTypeE Γ e .pt) → HasTypeE Γ (.setLit xs) .setPt
  | pair : HasTypeE Γ e₁ τ₁ → HasTypeE Γ e₂ τ₂ → HasTypeE Γ (.pair e₁ e₂) (.pair τ₁ τ₂)
  | fst  : HasTypeE Γ e (.pair τ₁ τ₂) → HasTypeE Γ (.fst e) τ₁
  | snd  : HasTypeE Γ e (.pair τ₁ τ₂) → HasTypeE Γ (.snd e) τ₂
  | mem  : HasTypeE Γ e₁ .pt → HasTypeE Γ e₂ .setPt → HasTypeE Γ (.mem e₁ e₂) .bool
  | insert : HasTypeE Γ e₁ .setPt → HasTypeE Γ e₂ .pt → HasTypeE Γ (.insert e₁ e₂) .setPt
  | min  : HasTypeE Γ e₁ .real → HasTypeE Γ e₂ .real → HasTypeE Γ (.min e₁ e₂) .real
  | max  : HasTypeE Γ e₁ .real → HasTypeE Γ e₂ .real → HasTypeE Γ (.max e₁ e₂) .real
  | le   : HasTypeE Γ e₁ .real → HasTypeE Γ e₂ .real → HasTypeE Γ (.le e₁ e₂) .bool

inductive HasTypeP : Ctx → Prog → Ty → Effect → Prop where
  | ret
      (h : HasTypeE Γ e τ) :
      HasTypeP Γ (.ret e) τ Effect.zero

  | dist
      (h₁ : HasTypeE Γ e₁ .pt)
      (h₂ : HasTypeE Γ e₂ .pt) :
      HasTypeP Γ (.dist e₁ e₂) .real ⟨1, δ₀⟩

  | apiDist
      (h₁ : HasTypeE Γ e₁ .pt)
      (h₂ : HasTypeE Γ e₂ .pt) :
      HasTypeP Γ (.apiDist e₁ e₂) .real ⟨1, δ₀⟩

  | letP
      (h₁ : HasTypeP Γ p₁ τ₁ e₁)
      (h₂ : HasTypeP ((x, τ₁) :: Γ) p₂ τ₂ e₂) :
      HasTypeP Γ (.letP x p₁ p₂) τ₂ (Effect.add e₁ e₂)

  | ite
      (hc : HasTypeE Γ c .bool)
      (h₁ : HasTypeP Γ p₁ τ e₁)
      (h₂ : HasTypeP Γ p₂ τ e₂) :
      HasTypeP Γ (.ite c p₁ p₂) τ (Effect.max e₁ e₂)

  | fold
      (hs : HasTypeE Γ eS .setPt)
      (hz : HasTypeE Γ ez τ)
      (hb : HasTypeP ((x, .pt) :: (s, τ) :: Γ) body τ ebody) :
      HasTypeP Γ (.fold n eS ez x s body) τ ⟨n * ebody.q, n * ebody.δ⟩

structure KCTyping (Γ : Ctx) (P : Prog) (α β q δ : Nat) : Prop where
  base : HasTypeP Γ P .setPt ⟨q, δ⟩
  sound :
    ∀ {ρ : Env} {M : MetricModel} {oracle : PointId → PointId → Int} {C : Value} {π : Trace},
      EnvModels Γ ρ →
      GoodTrace M q β π →
      Value.hasType C .setPt

end TypedKCenter
