import TypedKCenter.Basic

namespace TypedKCenter

abbrev Var := String
abbrev Ctx := List (Var × Ty)
abbrev Env := List (Var × Value)

inductive Expr where
  | var    (x : Var)
  | ptLit  (p : PointId)
  | realLit (z : Int)
  | natLit (n : Nat)
  | boolLit (b : Bool)
  | emptySet
  | setLit (xs : List Expr)
  | pair   (e₁ e₂ : Expr)
  | fst    (e : Expr)
  | snd    (e : Expr)
  | mem    (e₁ e₂ : Expr)
  | insert (e₁ e₂ : Expr)
  | min    (e₁ e₂ : Expr)
  | max    (e₁ e₂ : Expr)
  | le     (e₁ e₂ : Expr)
  deriving Repr, DecidableEq

inductive Prog where
  | ret     (e : Expr)
  | dist    (e₁ e₂ : Expr)
  | apiDist (e₁ e₂ : Expr)
  | letP    (x : Var) (p₁ p₂ : Prog)
  | ite     (e : Expr) (p₁ p₂ : Prog)
  | fold    (bound : Nat) (setExpr seed : Expr) (x s : Var) (body : Prog)
  deriving Repr, DecidableEq

namespace Ctx

def lookup (Γ : Ctx) (x : Var) : Option Ty :=
  match Γ with
  | [] => none
  | (y, τ) :: Γ' => if x = y then some τ else lookup Γ' x

end Ctx

namespace Env

def lookup (ρ : Env) (x : Var) : Option Value :=
  match ρ with
  | [] => none
  | (y, v) :: ρ' => if x = y then some v else lookup ρ' x


def update (ρ : Env) (x : Var) (v : Value) : Env :=
  (x, v) :: ρ

end Env

def EnvModels (Γ : Ctx) (ρ : Env) : Prop :=
  ∀ x τ, Ctx.lookup Γ x = some τ → ∃ v, Env.lookup ρ x = some v ∧ Value.hasType v τ

end TypedKCenter
