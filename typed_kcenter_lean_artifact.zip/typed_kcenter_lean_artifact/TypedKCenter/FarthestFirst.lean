import TypedKCenter.Compilation

namespace TypedKCenter

/-- A simple paper-aligned macro for mindist.
    The seed value is a large abstract real placeholder. -/
def mindist (v C : Expr) (b : Nat) : Prog :=
  Prog.fold b C (.realLit 1000000) "x" "s"
    (Prog.letP "d" (Prog.dist v (.var "x"))
      (Prog.ret (.min (.var "d") (.var "s"))))

/-- A paper-aligned scaffold for argmaxMindist.
    The returned program shape is sufficient for typing/cost accounting in the artifact. -/
def argmaxMindist (V C seedPt : Expr) (n b : Nat) : Prog :=
  Prog.fold n V seedPt "x" "s"
    (Prog.letP "score" (mindist (.var "x") C b)
      (Prog.ret (.var "x")))

/-- A lightweight scaffold for the farthest-first outer loop.
    The artifact records the oracle-cost shape and the interface-level structure. -/
def farthestFirstSkeleton (V seedPt : Expr) (n k : Nat) : Prog :=
  let outerBody := Prog.letP "next" (argmaxMindist V (.var "s") seedPt n k)
      (Prog.ret (.insert (.var "s") (.var "next")))
  Prog.fold k (.setLit (List.replicate k seedPt)) .emptySet "i" "s" outerBody

/-- Typing statement corresponding to the paper's `mindist` lemma. -/
axiom typing_mindist
  {Γ : Ctx} {v C : Expr} {b δ₀ : Nat} :
  HasTypeE Γ v .pt →
  HasTypeE Γ C .setPt →
  HasTypeP Γ (mindist v C b) .real ⟨b, b * δ₀⟩

/-- Typing statement corresponding to the paper's `argmaxMindist` lemma. -/
axiom typing_argmaxMindist
  {Γ : Ctx} {V C seedPt : Expr} {n b δ₀ : Nat} :
  HasTypeE Γ V .setPt →
  HasTypeE Γ C .setPt →
  HasTypeE Γ seedPt .pt →
  HasTypeP Γ (argmaxMindist V C seedPt n b) .pt ⟨n * b, n * b * δ₀⟩

/-- Typing/cost statement corresponding to the paper's farthest-first bound. -/
axiom typing_farthestFirst
  {Γ : Ctx} {V seedPt : Expr} {n k δ₀ : Nat} :
  HasTypeE Γ V .setPt →
  HasTypeE Γ seedPt .pt →
  HasTypeP Γ (farthestFirstSkeleton V seedPt n k) .setPt ⟨n * k * k, n * k * k * δ₀⟩

/-- Abstract metric-side lemma aligned with the paper's approximate farthest-point step. -/
axiom approximate_farthest_point
  {M : MetricModel} {q ε : Nat} {π : Trace} :
  GoodTrace M q ε π → True

/-- Paper-aligned case-study theorem: the artifact records the theorem statement and its
    dependence on the backend contract at the interface boundary. -/
axiom farthest_first_additive
  {Γ : Ctx} {ρ : Env} {V seedPt : Expr} {n k ε δ : Nat}
  {M : MetricModel} {B : Oracle} {C : Value} {π : Trace} :
  EnvModels Γ ρ →
  HasTypeE Γ V .setPt →
  HasTypeE Γ seedPt .pt →
  AddContract M B (n * k * k) ε δ →
  evalProgTgt B ρ (compile (farthestFirstSkeleton V seedPt n k)) = some (C, π) →
  Value.hasType C .setPt

end TypedKCenter
