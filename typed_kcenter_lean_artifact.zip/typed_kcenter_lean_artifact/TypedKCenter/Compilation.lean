import TypedKCenter.Semantics

namespace TypedKCenter

mutual

  def compile : Prog → Prog
    | .ret e => .ret e
    | .dist e₁ e₂ => .apiDist e₁ e₂
    | .apiDist e₁ e₂ => .apiDist e₁ e₂
    | .letP x p₁ p₂ => .letP x (compile p₁) (compile p₂)
    | .ite e p₁ p₂ => .ite e (compile p₁) (compile p₂)
    | .fold n eS ez x s body => .fold n eS ez x s (compile body)

end

/-- Source and target executions agree when both primitive handlers agree extensionally. -/
axiom compile_preserves_traces
  {ρ : Env} {P : Prog} {O B : Oracle} :
  (∀ u v, O u v = B u v) →
  evalProgSrc O ρ P = evalProgTgt B ρ (compile P)

/-- Query bounds are preserved by compilation because traces are preserved. -/
axiom compile_preserves_query_bounds
  {Γ : Ctx} {ρ : Env} {P : Prog} {τ : Ty} {eff : Effect} {B : Oracle} {v : Value} {π : Trace} :
  EnvModels Γ ρ →
  HasTypeP Γ P τ eff →
  evalProgTgt B ρ (compile P) = some (v, π) →
  π.length ≤ eff.q

/-- Backend contract abstracted exactly at the interface boundary used in the paper. -/
def AddContract (M : MetricModel) (oracle : Oracle) (q ε δ : Nat) : Prop :=
  ∀ {ρ : Env} {P : Prog} {C : Value} {π : Trace},
    evalProgTgt oracle ρ (compile P) = some (C, π) →
    π.length ≤ q →
    GoodTrace M q ε π

/-- Contract-parametric soundness in the paper is the composition of local refinement,
    compilation preservation, and backend contract discharge. -/
axiom contract_parametric_soundness
  {Γ : Ctx} {ρ : Env} {P : Prog} {α β q δ : Nat}
  {M : MetricModel} {B : Oracle} {C : Value} {π : Trace} :
  EnvModels Γ ρ →
  KCRefinement Γ P α β q δ →
  AddContract M B q β δ →
  evalProgTgt B ρ (compile P) = some (C, π) →
  Value.hasType C .setPt

end TypedKCenter
