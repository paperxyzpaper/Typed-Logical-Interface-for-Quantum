namespace TypedKCenter

abbrev PointId := Nat

inductive Ty where
  | pt
  | real
  | nat
  | bool
  | setPt
  | pair (a b : Ty)
  deriving Repr, DecidableEq

structure Effect where
  q : Nat
  δ : Nat
  deriving Repr, DecidableEq

namespace Effect

def zero : Effect := ⟨0, 0⟩

def add (e₁ e₂ : Effect) : Effect := ⟨e₁.q + e₂.q, e₁.δ + e₂.δ⟩

def max (e₁ e₂ : Effect) : Effect := ⟨Nat.max e₁.q e₂.q, Nat.max e₁.δ e₂.δ⟩

end Effect

inductive Value where
  | pt (p : PointId)
  | real (z : Int)
  | nat (n : Nat)
  | bool (b : Bool)
  | setPt (xs : List PointId)
  | pair (v₁ v₂ : Value)
  deriving Repr, DecidableEq

namespace Value

def hasType : Value -> Ty -> Prop
  | .pt _,      .pt        => True
  | .real _,    .real      => True
  | .nat _,     .nat       => True
  | .bool _,    .bool      => True
  | .setPt _,   .setPt     => True
  | .pair a b,  .pair τ σ  => hasType a τ ∧ hasType b σ
  | _,          _          => False

end Value

structure TraceEntry where
  u   : PointId
  v   : PointId
  est : Int
  deriving Repr, DecidableEq

abbrev Trace := List TraceEntry

structure MetricModel where
  trueDist : PointId → PointId → Int

namespace Trace

def length (π : Trace) : Nat := List.length π

end Trace

def intAbsLeNat (z : Int) (n : Nat) : Prop := Int.natAbs z ≤ n

def GoodTrace (M : MetricModel) (q ε : Nat) (π : Trace) : Prop :=
  π.length ≤ q ∧
  ∀ e ∈ π, intAbsLeNat (e.est - M.trueDist e.u e.v) ε

end TypedKCenter
