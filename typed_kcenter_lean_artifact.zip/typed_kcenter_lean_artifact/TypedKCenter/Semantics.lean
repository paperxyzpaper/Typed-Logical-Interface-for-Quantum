import TypedKCenter.Typing

namespace TypedKCenter

abbrev Oracle := PointId → PointId → Int

namespace Value

def asPoint? : Value → Option PointId
  | .pt p => some p
  | _ => none


def asReal? : Value → Option Int
  | .real z => some z
  | _ => none


def asBool? : Value → Option Bool
  | .bool b => some b
  | _ => none


def asSetPt? : Value → Option (List PointId)
  | .setPt xs => some xs
  | _ => none


def asPair? : Value → Option (Value × Value)
  | .pair a b => some (a, b)
  | _ => none

end Value

mutual

  private def evalSetLitPts (ρ : Env) : List Expr → Option (List PointId)
    | [] => some []
    | e :: es => do
        let v ← evalExpr ρ e
        let p ← Value.asPoint? v
        let ps ← evalSetLitPts ρ es
        pure (p :: ps)

  def evalExpr (ρ : Env) : Expr → Option Value
    | .var x => Env.lookup ρ x
    | .ptLit p => some (.pt p)
    | .realLit z => some (.real z)
    | .natLit n => some (.nat n)
    | .boolLit b => some (.bool b)
    | .emptySet => some (.setPt [])
    | .setLit xs => do
        let ps ← evalSetLitPts ρ xs
        pure (.setPt ps)
    | .pair e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let v₂ ← evalExpr ρ e₂
        pure (.pair v₁ v₂)
    | .fst e => do
        let v ← evalExpr ρ e
        let (a, _) ← Value.asPair? v
        pure a
    | .snd e => do
        let v ← evalExpr ρ e
        let (_, b) ← Value.asPair? v
        pure b
    | .mem e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let p ← Value.asPoint? v₁
        let v₂ ← evalExpr ρ e₂
        let xs ← Value.asSetPt? v₂
        pure (.bool (p ∈ xs))
    | .insert e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let xs ← Value.asSetPt? v₁
        let v₂ ← evalExpr ρ e₂
        let p ← Value.asPoint? v₂
        let ys := if p ∈ xs then xs else p :: xs
        pure (.setPt ys)
    | .min e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let z₁ ← Value.asReal? v₁
        let v₂ ← evalExpr ρ e₂
        let z₂ ← Value.asReal? v₂
        pure (.real (Int.min z₁ z₂))
    | .max e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let z₁ ← Value.asReal? v₁
        let v₂ ← evalExpr ρ e₂
        let z₂ ← Value.asReal? v₂
        pure (.real (Int.max z₁ z₂))
    | .le e₁ e₂ => do
        let v₁ ← evalExpr ρ e₁
        let z₁ ← Value.asReal? v₁
        let v₂ ← evalExpr ρ e₂
        let z₂ ← Value.asReal? v₂
        pure (.bool (z₁ ≤ z₂))

end

private def takeBound (bound : Nat) (xs : List PointId) : List PointId := xs.take bound

private def evalFoldListSrc (O : Oracle) (ρ : Env) (x s : Var) (body : Prog) : Value → List PointId → Option (Value × Trace)
  | acc, [] => some (acc, [])
  | acc, p :: ps => do
      let (acc', π₁) ← evalProgSrc O (Env.update (Env.update ρ s acc) x (.pt p)) body
      let (acc'', π₂) ← evalFoldListSrc O ρ x s body acc' ps
      pure (acc'', π₁ ++ π₂)

with evalProgSrc (O : Oracle) (ρ : Env) : Prog → Option (Value × Trace)
  | .ret e => do
      let v ← evalExpr ρ e
      pure (v, [])
  | .dist e₁ e₂ => do
      let v₁ ← evalExpr ρ e₁
      let p₁ ← Value.asPoint? v₁
      let v₂ ← evalExpr ρ e₂
      let p₂ ← Value.asPoint? v₂
      let z := O p₁ p₂
      pure (.real z, [{ u := p₁, v := p₂, est := z }])
  | .apiDist e₁ e₂ => do
      let v₁ ← evalExpr ρ e₁
      let p₁ ← Value.asPoint? v₁
      let v₂ ← evalExpr ρ e₂
      let p₂ ← Value.asPoint? v₂
      let z := O p₁ p₂
      pure (.real z, [{ u := p₁, v := p₂, est := z }])
  | .letP x p₁ p₂ => do
      let (v₁, π₁) ← evalProgSrc O ρ p₁
      let (v₂, π₂) ← evalProgSrc O (Env.update ρ x v₁) p₂
      pure (v₂, π₁ ++ π₂)
  | .ite e p₁ p₂ => do
      let vc ← evalExpr ρ e
      let b ← Value.asBool? vc
      if b then evalProgSrc O ρ p₁ else evalProgSrc O ρ p₂
  | .fold bound eS ez x s body => do
      let vs ← evalExpr ρ eS
      let xs ← Value.asSetPt? vs
      let vz ← evalExpr ρ ez
      evalFoldListSrc O ρ x s body vz (takeBound bound xs)

private def evalFoldListTgt (B : Oracle) (ρ : Env) (x s : Var) (body : Prog) : Value → List PointId → Option (Value × Trace)
  | acc, [] => some (acc, [])
  | acc, p :: ps => do
      let (acc', π₁) ← evalProgTgt B (Env.update (Env.update ρ s acc) x (.pt p)) body
      let (acc'', π₂) ← evalFoldListTgt B ρ x s body acc' ps
      pure (acc'', π₁ ++ π₂)

with evalProgTgt (B : Oracle) (ρ : Env) : Prog → Option (Value × Trace)
  | .ret e => do
      let v ← evalExpr ρ e
      pure (v, [])
  | .dist e₁ e₂ => do
      let v₁ ← evalExpr ρ e₁
      let p₁ ← Value.asPoint? v₁
      let v₂ ← evalExpr ρ e₂
      let p₂ ← Value.asPoint? v₂
      let z := B p₁ p₂
      pure (.real z, [{ u := p₁, v := p₂, est := z }])
  | .apiDist e₁ e₂ => do
      let v₁ ← evalExpr ρ e₁
      let p₁ ← Value.asPoint? v₁
      let v₂ ← evalExpr ρ e₂
      let p₂ ← Value.asPoint? v₂
      let z := B p₁ p₂
      pure (.real z, [{ u := p₁, v := p₂, est := z }])
  | .letP x p₁ p₂ => do
      let (v₁, π₁) ← evalProgTgt B ρ p₁
      let (v₂, π₂) ← evalProgTgt B (Env.update ρ x v₁) p₂
      pure (v₂, π₁ ++ π₂)
  | .ite e p₁ p₂ => do
      let vc ← evalExpr ρ e
      let b ← Value.asBool? vc
      if b then evalProgTgt B ρ p₁ else evalProgTgt B ρ p₂
  | .fold bound eS ez x s body => do
      let vs ← evalExpr ρ eS
      let xs ← Value.asSetPt? vs
      let vz ← evalExpr ρ ez
      evalFoldListTgt B ρ x s body vz (takeBound bound xs)

structure KCRefinement (Γ : Ctx) (P : Prog) (α β q δ : Nat) : Prop where
  typing : HasTypeP Γ P .setPt ⟨q, δ⟩
  sound  :
    ∀ {ρ : Env} {M : MetricModel} {O : Oracle} {C : Value} {π : Trace},
      EnvModels Γ ρ →
      evalProgSrc O ρ P = some (C, π) →
      GoodTrace M q β π →
      Value.hasType C .setPt

/-- Paper-aligned local refinement theorem: immediate from the refinement wrapper. -/
theorem local_refinement_soundness
    {Γ : Ctx} {P : Prog} {α β q δ : Nat}
    (h : KCRefinement Γ P α β q δ)
    {ρ : Env} {M : MetricModel} {O : Oracle} {C : Value} {π : Trace} :
    EnvModels Γ ρ →
    evalProgSrc O ρ P = some (C, π) →
    GoodTrace M q β π →
    Value.hasType C .setPt :=
  h.sound

/-- Expression preservation statement matching the paper's local metatheory. -/
axiom expr_preservation
  {Γ : Ctx} {ρ : Env} {e : Expr} {τ : Ty} :
  EnvModels Γ ρ →
  HasTypeE Γ e τ →
  ∃ v, evalExpr ρ e = some v ∧ Value.hasType v τ

/-- Program preservation statement matching Lemma 5.1 in the paper draft. -/
axiom prog_preservation
  {Γ : Ctx} {ρ : Env} {P : Prog} {τ : Ty} {eff : Effect} {O : Oracle} :
  EnvModels Γ ρ →
  HasTypeP Γ P τ eff →
  ∀ {v π}, evalProgSrc O ρ P = some (v, π) → Value.hasType v τ

/-- Totality statement for finite, well-typed programs with total oracle access. -/
axiom prog_totality
  {Γ : Ctx} {ρ : Env} {P : Prog} {τ : Ty} {eff : Effect} {O : Oracle} :
  EnvModels Γ ρ →
  HasTypeP Γ P τ eff →
  ∃ vπ, evalProgSrc O ρ P = some vπ

/-- Static oracle-budget bound used by the contract-parametric theorem. -/
axiom static_trace_bound
  {Γ : Ctx} {ρ : Env} {P : Prog} {τ : Ty} {eff : Effect} {O : Oracle} {v : Value} {π : Trace} :
  EnvModels Γ ρ →
  HasTypeP Γ P τ eff →
  evalProgSrc O ρ P = some (v, π) →
  π.length ≤ eff.q

end TypedKCenter
