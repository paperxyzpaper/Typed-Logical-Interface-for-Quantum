# Reviewer Artifact Note

This artifact accompanies the paper
**"A Typed Logical Interface for Quantum-Oracular k-Center"**.

## Scope of the artifact

The artifact formalizes the following paper components.

1. A typed DSL with explicit oracle effects.
2. Trace-based operational semantics.
3. A syntax-directed compilation map from source oracle calls to backend API calls.
4. A refinement wrapper for the problem-specific specification `KC(α,β)`.
5. A case-study scaffold for farthest-first and its oracle-cost accounting.

## Intended interpretation

The artifact formalizes the **oracle-interface metatheory** of the paper.
It does **not** attempt to formalize gate-level semantics of a quantum language.
The quantum component is abstracted as a backend oracle satisfying a contract.

## Files to inspect first

- `TypedKCenter/Typing.lean`
- `TypedKCenter/Semantics.lean`
- `TypedKCenter/Compilation.lean`
- `TypedKCenter/FarthestFirst.lean`

## Build expectation

The package is prepared for Lean 4 / Lake.
A final submission version should be checked with `lake build` in a standard Lean 4 environment.

