# TypedKCenter Lean Artifact

This package is an anonymous review-oriented Lean 4 artifact scaffold matching the paper
**"A Typed Logical Interface for Quantum-Oracular k-Center"**.

## What is included

The package contains a paper-aligned formalization layout:

- `TypedKCenter/Basic.lean` — basic types, values, effects, traces, and good-trace predicates
- `TypedKCenter/Syntax.lean` — source syntax, target primitive, contexts, and environments
- `TypedKCenter/Typing.lean` — expression/program typing rules and the refinement wrapper
- `TypedKCenter/Semantics.lean` — executable-style trace semantics and helper definitions
- `TypedKCenter/Compilation.lean` — compilation function and trace-preservation statements
- `TypedKCenter/FarthestFirst.lean` — paper-aligned case-study scaffolding for `mindist`, `argmaxMindist`, and farthest-first
- `TypedKCenter.lean` — umbrella import file
- `REVIEWER_ARTIFACT_NOTE.md` — short note intended for anonymous reviewers

## Important note

This environment does **not** include Lean, so the package could not be built locally here with `lake build`.
Accordingly, the files are prepared to match the paper structure and to be suitable for upload to an anonymous GitHub repository,
but they should still be checked in a Lean 4 environment before submission.

To keep the artifact honest and readable, the package separates:

- **explicit formal definitions** that mirror the paper, and
- **paper-level theorem statements / refinement wrappers** used to document the intended metatheory.

The formalization targets the **typed oracle-interface layer** of the paper.
It is **not** a gate-level semantics of a quantum programming language.
The quantum backend is abstracted as an oracle/back-end satisfying a contract.

## Suggested anonymous repository layout

Upload the folder contents as the root of an anonymous repository, for example:

```text
anonymous-artifact/
  lakefile.toml
  lean-toolchain
  TypedKCenter.lean
  TypedKCenter/
    Basic.lean
    Syntax.lean
    Typing.lean
    Semantics.lean
    Compilation.lean
    FarthestFirst.lean
  README.md
  REVIEWER_ARTIFACT_NOTE.md
```

## Suggested reviewer sentence for the paper

> An anonymous Lean 4 artifact accompanies the submission and contains the formal syntax,
> typing rules, trace semantics, compilation function, and proof organization for the core
> metatheory and the farthest-first case study.

