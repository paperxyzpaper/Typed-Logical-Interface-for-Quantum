from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def main():
    outdir = Path(__file__).resolve().parents[1] / "figures"
    outdir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(7)
    runs = 18
    queries = 32
    eps = 0.18
    data = rng.normal(loc=0.0, scale=0.07, size=(runs, queries))
    drift = np.linspace(-0.03, 0.03, queries)
    data = data + drift[None, :]
    data = np.clip(data, -eps, eps)

    plt.figure(figsize=(7.0, 4.5))
    im = plt.imshow(data, aspect="auto", interpolation="nearest")
    plt.colorbar(im, label="signed estimation error")
    plt.xlabel("query index")
    plt.ylabel("run / stage")
    plt.title(r"Illustrative oracle-trace heatmap within $\pm \varepsilon$")
    plt.tight_layout()
    plt.savefig(outdir / "fig_oracle_trace_heatmap.pdf")
    plt.savefig(outdir / "fig_oracle_trace_heatmap.png", dpi=220)
    plt.close()

if __name__ == "__main__":
    main()
