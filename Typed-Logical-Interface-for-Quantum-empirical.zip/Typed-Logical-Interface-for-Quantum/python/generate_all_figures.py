from generate_radius_sweep import main as radius_main
from generate_oracle_trace_heatmap import main as heatmap_main

if __name__ == "__main__":
    radius_main()
    heatmap_main()
    print("Generated figures in ../figures/")
