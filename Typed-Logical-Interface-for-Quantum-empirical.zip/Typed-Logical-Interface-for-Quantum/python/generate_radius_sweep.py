import os
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def main():
    outdir = Path(__file__).resolve().parents[1] / "figures"
    outdir.mkdir(parents=True, exist_ok=True)

    eps = np.linspace(0.0, 1.5, 200)
    opt = 1.2
    exact_baseline = np.full_like(eps, 2 * opt)
    oracle_curve = 2 * opt + 1.5 * eps + 0.08 * np.sin(5 * eps)
    theorem_curve = 2 * opt + 2 * eps

    plt.figure(figsize=(6.4, 4.3))
    plt.plot(eps, exact_baseline, label="exact farthest-first baseline")
    plt.plot(eps, oracle_curve, label="oracle-based illustrative radius")
    plt.plot(eps, theorem_curve, label=r"theoretical line $2\mathrm{OPT}+2\varepsilon$")
    plt.xlabel(r"oracle error level $\varepsilon$")
    plt.ylabel("radius")
    plt.title("Illustrative radius sweep under additive oracle error")
    plt.legend(frameon=True)
    plt.tight_layout()
    plt.savefig(outdir / "fig_radius_sweep.pdf")
    plt.savefig(outdir / "fig_radius_sweep.png", dpi=220)
    plt.close()

if __name__ == "__main__":
    main()
