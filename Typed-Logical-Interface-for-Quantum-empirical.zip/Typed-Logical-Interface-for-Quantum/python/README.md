# Python reproducibility artifact

This directory contains scripts that generate the illustrative figures used in the paper.

## Scripts
- `generate_radius_sweep.py`
- `generate_oracle_trace_heatmap.py`
- `generate_all_figures.py`

## Output
Generated files are written to `../figures/`.

## Role
This directory is a **reproducibility artifact**. It supports figure regeneration and paper packaging.
It is not the formal proof artifact.


## Empirical extension
For experiment-oriented scripts, see `empirical/`. These scripts generate CSV summaries, empirical curves, and trace heatmaps from repeated noisy-oracle trials.
