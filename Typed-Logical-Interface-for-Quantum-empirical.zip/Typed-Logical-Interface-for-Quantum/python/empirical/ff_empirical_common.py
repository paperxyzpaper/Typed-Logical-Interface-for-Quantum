from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple
import math

import numpy as np


Array = np.ndarray


def pairwise_distances(points: Array) -> Array:
    """Return the full Euclidean distance matrix for points of shape (n, d)."""
    diff = points[:, None, :] - points[None, :, :]
    return np.sqrt(np.sum(diff * diff, axis=2))


def radius_from_centers(dist: Array, centers: List[int]) -> float:
    if not centers:
        raise ValueError("centers must be non-empty")
    nearest = np.min(dist[:, centers], axis=1)
    return float(np.max(nearest))


def farthest_first_exact(dist: Array, k: int, start: int = 0) -> List[int]:
    n = dist.shape[0]
    if not (1 <= k <= n):
        raise ValueError("k must satisfy 1 <= k <= n")
    centers = [start]
    while len(centers) < k:
        nearest = np.min(dist[:, centers], axis=1)
        next_center = int(np.argmax(nearest))
        if next_center in centers:
            # deterministic fallback in degenerate cases
            for j in range(n):
                if j not in centers:
                    next_center = j
                    break
        centers.append(next_center)
    return centers


@dataclass
class OracleTrace:
    errors: List[float]
    estimated_values: List[float]
    true_values: List[float]


def farthest_first_noisy(
    dist: Array,
    k: int,
    epsilon: float,
    rng: np.random.Generator,
    start: int = 0,
    noise_model: str = "uniform",
) -> Tuple[List[int], OracleTrace]:
    """Run noisy farthest-first with per-query additive noise in [-eps, eps] or N(0, eps/2).

    This is an empirical stress-test script, not the theorem itself. It simulates oracle answers.
    """
    n = dist.shape[0]
    if not (1 <= k <= n):
        raise ValueError("k must satisfy 1 <= k <= n")
    centers = [start]
    errors: List[float] = []
    estimated_values: List[float] = []
    true_values: List[float] = []

    def sample_noise(size: int) -> Array:
        if noise_model == "uniform":
            return rng.uniform(-epsilon, epsilon, size=size)
        if noise_model == "gaussian":
            # clipped gaussian to keep additive noise controlled at roughly epsilon scale
            vals = rng.normal(0.0, epsilon / 2.0 if epsilon > 0 else 0.0, size=size)
            return np.clip(vals, -epsilon, epsilon)
        raise ValueError(f"unsupported noise_model: {noise_model}")

    while len(centers) < k:
        est_scores = np.empty(n, dtype=float)
        true_scores = np.min(dist[:, centers], axis=1)
        for v in range(n):
            current_true = []
            current_est = []
            for c in centers:
                true_d = float(dist[v, c])
                err = float(sample_noise(1)[0])
                est_d = true_d + err
                errors.append(err)
                estimated_values.append(est_d)
                true_values.append(true_d)
                current_true.append(true_d)
                current_est.append(est_d)
            est_scores[v] = min(current_est)
        next_center = int(np.argmax(est_scores))
        if next_center in centers:
            for j in range(n):
                if j not in centers:
                    next_center = j
                    break
        centers.append(next_center)
    return centers, OracleTrace(errors=errors, estimated_values=estimated_values, true_values=true_values)


def synth_instance(
    n: int,
    d: int,
    kind: str,
    rng: np.random.Generator,
) -> Array:
    """Generate a small synthetic point cloud."""
    if kind == "gaussian_mixture":
        num_clusters = min(4, max(2, n // 15))
        means = rng.uniform(-4.0, 4.0, size=(num_clusters, d))
        labels = rng.integers(0, num_clusters, size=n)
        pts = means[labels] + rng.normal(0.0, 0.7, size=(n, d))
        return pts
    if kind == "uniform_box":
        return rng.uniform(-5.0, 5.0, size=(n, d))
    if kind == "ring":
        if d < 2:
            raise ValueError("ring instances require d >= 2")
        theta = rng.uniform(0.0, 2.0 * math.pi, size=n)
        radius = 3.0 + rng.normal(0.0, 0.15, size=n)
        pts = np.zeros((n, d), dtype=float)
        pts[:, 0] = radius * np.cos(theta)
        pts[:, 1] = radius * np.sin(theta)
        if d > 2:
            pts[:, 2:] = rng.normal(0.0, 0.1, size=(n, d - 2))
        return pts
    raise ValueError(f"unsupported instance kind: {kind}")


def brute_force_opt_radius(dist: Array, k: int) -> float:
    """Exact OPT by brute force for small n only."""
    from itertools import combinations

    n = dist.shape[0]
    if n > 22:
        raise ValueError("brute_force_opt_radius is intended only for small n")
    best = float("inf")
    for centers in combinations(range(n), k):
        best = min(best, radius_from_centers(dist, list(centers)))
    return float(best)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
