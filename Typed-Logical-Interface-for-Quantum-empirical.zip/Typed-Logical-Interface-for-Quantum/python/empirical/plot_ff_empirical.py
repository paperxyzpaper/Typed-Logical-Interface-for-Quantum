from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot empirical farthest-first results from CSV.")
    parser.add_argument("--csv", type=str, default="../../figures/empirical/ff_empirical_results.csv")
    parser.add_argument("--outdir", type=str, default="../../figures/empirical")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    base = Path(__file__).resolve().parent
    csv_path = (base / args.csv).resolve()
    outdir = (base / args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(csv_path)

    plt.figure(figsize=(7.2, 4.8))
    plt.plot(df["epsilon"], df["mean_noisy_ff_radius"], marker="o", label="Empirical mean noisy FF radius")
    plt.fill_between(
        df["epsilon"],
        df["mean_noisy_ff_radius"] - df["std_noisy_ff_radius"],
        df["mean_noisy_ff_radius"] + df["std_noisy_ff_radius"],
        alpha=0.2,
        label="±1 std",
    )
    plt.plot(df["epsilon"], df["exact_ff_radius"], linestyle="--", label="Exact FF radius")
    if "theory_bound" in df.columns and df["theory_bound"].notna().all():
        plt.plot(df["epsilon"], df["theory_bound"], linestyle=":", linewidth=2, label=r"Theory bound $2\mathrm{OPT}+2\varepsilon$")
    plt.xlabel(r"Oracle error level $\varepsilon$")
    plt.ylabel("Radius")
    plt.title("Empirical farthest-first performance under additive oracle noise")
    plt.legend()
    plt.tight_layout()
    pdf_path = outdir / "ff_empirical_curve.pdf"
    png_path = outdir / "ff_empirical_curve.png"
    plt.savefig(pdf_path)
    plt.savefig(png_path, dpi=220)
    plt.close()

    print(f"Wrote {pdf_path}")
    print(f"Wrote {png_path}")


if __name__ == "__main__":
    main()
