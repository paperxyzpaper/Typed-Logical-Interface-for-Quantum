from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ff_empirical_common import (
    brute_force_opt_radius,
    ensure_dir,
    farthest_first_exact,
    farthest_first_noisy,
    pairwise_distances,
    radius_from_centers,
    synth_instance,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run empirical farthest-first experiments under additive oracle noise.")
    parser.add_argument("--n", type=int, default=18, help="number of points; keep <= 22 if exact OPT is desired")
    parser.add_argument("--d", type=int, default=2, help="ambient dimension")
    parser.add_argument("--k", type=int, default=3, help="number of centers")
    parser.add_argument("--trials", type=int, default=80, help="number of noisy trials per epsilon")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--instance", type=str, default="gaussian_mixture", choices=["gaussian_mixture", "uniform_box", "ring"])
    parser.add_argument("--eps-grid", type=str, default="0.0,0.05,0.10,0.20,0.30,0.40,0.50")
    parser.add_argument("--noise-model", type=str, default="uniform", choices=["uniform", "gaussian"])
    parser.add_argument("--outdir", type=str, default="../../figures/empirical")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    outdir = ensure_dir(Path(__file__).resolve().parent / args.outdir)

    rng = np.random.default_rng(args.seed)
    points = synth_instance(args.n, args.d, args.instance, rng)
    dist = pairwise_distances(points)

    eps_values = [float(x.strip()) for x in args.eps_grid.split(",") if x.strip()]

    exact_centers = farthest_first_exact(dist, args.k, start=0)
    exact_radius = radius_from_centers(dist, exact_centers)
    opt_radius = brute_force_opt_radius(dist, args.k) if args.n <= 22 else np.nan

    rows = []
    trace_rows = []

    for eps in eps_values:
        noisy_radii = []
        for t in range(args.trials):
            trial_rng = np.random.default_rng(args.seed * 1000 + int(round(eps * 1000)) * 17 + t)
            centers, trace = farthest_first_noisy(
                dist,
                args.k,
                eps,
                trial_rng,
                start=0,
                noise_model=args.noise_model,
            )
            radius = radius_from_centers(dist, centers)
            noisy_radii.append(radius)
            for qidx, err in enumerate(trace.errors):
                trace_rows.append(
                    {
                        "epsilon": eps,
                        "trial": t,
                        "query_index": qidx,
                        "error": err,
                        "abs_error": abs(err),
                    }
                )

        noisy_radii_arr = np.asarray(noisy_radii, dtype=float)
        rows.append(
            {
                "epsilon": eps,
                "n": args.n,
                "d": args.d,
                "k": args.k,
                "instance": args.instance,
                "noise_model": args.noise_model,
                "trials": args.trials,
                "exact_ff_radius": exact_radius,
                "opt_radius": opt_radius,
                "mean_noisy_ff_radius": float(noisy_radii_arr.mean()),
                "std_noisy_ff_radius": float(noisy_radii_arr.std(ddof=1)) if len(noisy_radii_arr) > 1 else 0.0,
                "min_noisy_ff_radius": float(noisy_radii_arr.min()),
                "max_noisy_ff_radius": float(noisy_radii_arr.max()),
                "theory_bound": float(2.0 * opt_radius + 2.0 * eps) if not np.isnan(opt_radius) else np.nan,
            }
        )

    result_df = pd.DataFrame(rows)
    trace_df = pd.DataFrame(trace_rows)
    points_df = pd.DataFrame(points, columns=[f"x{i}" for i in range(points.shape[1])])

    result_csv = outdir / "ff_empirical_results.csv"
    trace_csv = outdir / "ff_empirical_trace.csv"
    points_csv = outdir / "ff_empirical_points.csv"
    result_df.to_csv(result_csv, index=False)
    trace_df.to_csv(trace_csv, index=False)
    points_df.to_csv(points_csv, index=False)

    print(f"Wrote results to {result_csv}")
    print(f"Wrote trace data to {trace_csv}")
    print(f"Wrote point cloud to {points_csv}")
    print(result_df.to_string(index=False))


if __name__ == "__main__":
    main()
