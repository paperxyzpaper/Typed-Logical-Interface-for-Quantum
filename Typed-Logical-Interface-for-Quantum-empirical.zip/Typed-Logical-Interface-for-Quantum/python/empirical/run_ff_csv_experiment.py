from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ff_empirical_common import (
    brute_force_opt_radius,
    ensure_dir,
    farthest_first_exact,
    farthest_first_noisy,
    pairwise_distances,
    radius_from_centers,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the same empirical study on points loaded from CSV.")
    parser.add_argument("--csv", type=str, required=True, help="CSV file with numeric coordinate columns")
    parser.add_argument("--k", type=int, default=3)
    parser.add_argument("--trials", type=int, default=80)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--eps-grid", type=str, default="0.0,0.05,0.10,0.20,0.30")
    parser.add_argument("--noise-model", type=str, default="uniform", choices=["uniform", "gaussian"])
    parser.add_argument("--outdir", type=str, default="../../figures/empirical/csv_case")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    base = Path(__file__).resolve().parent
    csv_path = Path(args.csv).resolve()
    outdir = ensure_dir(base / args.outdir)

    points = pd.read_csv(csv_path).select_dtypes(include=[np.number]).to_numpy(dtype=float)
    n = points.shape[0]
    if n < args.k:
        raise ValueError("k must be at most the number of points")
    dist = pairwise_distances(points)
    eps_values = [float(x.strip()) for x in args.eps_grid.split(",") if x.strip()]
    exact_centers = farthest_first_exact(dist, args.k, start=0)
    exact_radius = radius_from_centers(dist, exact_centers)
    opt_radius = brute_force_opt_radius(dist, args.k) if n <= 22 else np.nan

    rows = []
    for eps in eps_values:
        noisy_radii = []
        for t in range(args.trials):
            trial_rng = np.random.default_rng(args.seed * 1000 + int(round(eps * 1000)) * 17 + t)
            centers, _ = farthest_first_noisy(dist, args.k, eps, trial_rng, start=0, noise_model=args.noise_model)
            noisy_radii.append(radius_from_centers(dist, centers))
        vals = np.asarray(noisy_radii)
        rows.append(
            {
                "epsilon": eps,
                "n": n,
                "k": args.k,
                "trials": args.trials,
                "exact_ff_radius": exact_radius,
                "opt_radius": opt_radius,
                "mean_noisy_ff_radius": float(vals.mean()),
                "std_noisy_ff_radius": float(vals.std(ddof=1)) if len(vals) > 1 else 0.0,
                "theory_bound": float(2.0 * opt_radius + 2.0 * eps) if not np.isnan(opt_radius) else np.nan,
            }
        )
    out_csv = outdir / "ff_empirical_from_csv_results.csv"
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    print(f"Wrote {out_csv}")


if __name__ == "__main__":
    main()
