from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create an empirical oracle-trace heatmap from saved trace CSV.")
    parser.add_argument("--csv", type=str, default="../../figures/empirical/ff_empirical_trace.csv")
    parser.add_argument("--epsilon", type=float, default=None, help="plot one epsilon slice; default uses the largest epsilon")
    parser.add_argument("--max-trials", type=int, default=30)
    parser.add_argument("--outdir", type=str, default="../../figures/empirical")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    base = Path(__file__).resolve().parent
    csv_path = (base / args.csv).resolve()
    outdir = (base / args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(csv_path)
    if args.epsilon is None:
        eps = float(df["epsilon"].max())
    else:
        eps = float(args.epsilon)
    sdf = df[np.isclose(df["epsilon"], eps)]
    trials = sorted(sdf["trial"].unique())[: args.max_trials]
    sdf = sdf[sdf["trial"].isin(trials)]
    max_q = int(sdf["query_index"].max()) + 1
    trial_to_row = {t: i for i, t in enumerate(trials)}
    mat = np.full((len(trials), max_q), np.nan, dtype=float)
    for row in sdf.itertuples(index=False):
        mat[trial_to_row[row.trial], int(row.query_index)] = float(row.error)

    plt.figure(figsize=(9.0, 4.8))
    im = plt.imshow(mat, aspect="auto", interpolation="nearest")
    plt.colorbar(im, label="Signed estimation error")
    plt.xlabel("Query index")
    plt.ylabel("Trial")
    plt.title(fr"Empirical oracle-trace heatmap at $\varepsilon={eps:.2f}$")
    plt.tight_layout()
    pdf_path = outdir / "ff_empirical_trace_heatmap.pdf"
    png_path = outdir / "ff_empirical_trace_heatmap.png"
    plt.savefig(pdf_path)
    plt.savefig(png_path, dpi=220)
    plt.close()

    print(f"Wrote {pdf_path}")
    print(f"Wrote {png_path}")


if __name__ == "__main__":
    main()
