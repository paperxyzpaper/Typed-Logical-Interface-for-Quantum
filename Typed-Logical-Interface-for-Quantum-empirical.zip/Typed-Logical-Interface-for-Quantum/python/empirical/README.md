# Empirical Python artifact

This directory contains **empirical** scripts, distinct from the illustrative figure scripts in `../`.

## Purpose
These scripts can be used when the paper needs a reproducible experimental section rather than purely conceptual figures.
They produce:
- CSV summaries of repeated noisy farthest-first runs
- empirical radius-vs-epsilon plots
- empirical oracle-trace heatmaps

## Main scripts
- `run_ff_synthetic_experiment.py` — controlled synthetic experiment with repeated trials
- `plot_ff_empirical.py` — plot empirical mean/std curves from CSV output
- `plot_trace_heatmap_empirical.py` — create a heatmap from recorded oracle traces
- `run_ff_csv_experiment.py` — rerun the same study on a user-supplied CSV point set
- `generate_all_empirical.py` — one-command pipeline for the synthetic experiment

## Quick start
```bash
cd python/empirical
python generate_all_empirical.py
```

Outputs are written to `../../figures/empirical/`.

## Interpretation
These scripts generate **empirical evidence** for a controlled noisy-oracle model.
They are still not a claim about fault-tolerant quantum hardware performance.
A good paper phrasing is that these experiments evaluate the theorem's behavior under a simulated bounded-error oracle model.
