Place the latest LaTeX source of the paper here, e.g. `main.tex`, bibliography files, and local figure references.
