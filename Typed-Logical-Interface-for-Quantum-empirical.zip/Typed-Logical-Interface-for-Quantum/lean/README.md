# Lean artifact

This directory is the proof-oriented artifact.

## Files
- `TypedKCenter/Syntax.lean` — source syntax and contexts
- `TypedKCenter/Typing.lean` — pure/program typing and effect bounds
- `TypedKCenter/Semantics.lean` — trace-based big-step semantics
- `TypedKCenter/Compilation.lean` — target syntax and source-to-target compilation
- `TypedKCenter/FarthestFirst.lean` — case-study scaffold for farthest-first

## Role
These files correspond to the paper's formal sections. They are the proof-facing part of the repository.

## Note
The Python and `quantum_sim` directories are not proof artifacts. They serve reproducibility and backend illustration respectively.
