namespace TypedKCenter


import TypedKCenter.Syntax

open Ty PureExpr Prog

structure Eff where
  q : Nat
  δ : Rational
  deriving Repr, DecidableEq

def Eff.zero : Eff := ⟨0, 0⟩

def Eff.add (e₁ e₂ : Eff) : Eff := ⟨e₁.q + e₂.q, e₁.δ + e₂.δ⟩

def Eff.max (e₁ e₂ : Eff) : Eff := ⟨Nat.max e₁.q e₂.q, max e₁.δ e₂.δ⟩

inductive HasPureType : Ctx → PureExpr → Ty → Prop where
  | tVar {Γ x τ} :
      lookupCtx Γ x = some τ →
      HasPureType Γ (.var x) τ
  | tPt {Γ p} :
      HasPureType Γ (.ptLit p) .pt
  | tReal {Γ r} :
      HasPureType Γ (.realLit r) .real
  | tNat {Γ n} :
      HasPureType Γ (.natLit n) .nat
  | tBool {Γ b} :
      HasPureType Γ (.boolLit b) .bool
  | tEmpty {Γ} :
      HasPureType Γ .emptySet .setPt
  | tSingleton {Γ e} :
      HasPureType Γ e .pt →
      HasPureType Γ (.singletonSet e) .setPt
  | tFiniteSet {Γ es} :
      (∀ e ∈ es, HasPureType Γ e .pt) →
      HasPureType Γ (.finiteSet es) .setPt
  | tPair {Γ e₁ e₂ τ₁ τ₂} :
      HasPureType Γ e₁ τ₁ →
      HasPureType Γ e₂ τ₂ →
      HasPureType Γ (.pair e₁ e₂) (.pair τ₁ τ₂)
  | tFst {Γ e τ₁ τ₂} :
      HasPureType Γ e (.pair τ₁ τ₂) →
      HasPureType Γ (.fst e) τ₁
  | tSnd {Γ e τ₁ τ₂} :
      HasPureType Γ e (.pair τ₁ τ₂) →
      HasPureType Γ (.snd e) τ₂
  | tMem {Γ e₁ e₂} :
      HasPureType Γ e₁ .pt →
      HasPureType Γ e₂ .setPt →
      HasPureType Γ (.mem e₁ e₂) .bool
  | tInsert {Γ e₁ e₂} :
      HasPureType Γ e₁ .setPt →
      HasPureType Γ e₂ .pt →
      HasPureType Γ (.insert e₁ e₂) .setPt
  | tMin {Γ e₁ e₂} :
      HasPureType Γ e₁ .real →
      HasPureType Γ e₂ .real →
      HasPureType Γ (.min e₁ e₂) .real
  | tMax {Γ e₁ e₂} :
      HasPureType Γ e₁ .real →
      HasPureType Γ e₂ .real →
      HasPureType Γ (.max e₁ e₂) .real
  | tLe {Γ e₁ e₂} :
      HasPureType Γ e₁ .real →
      HasPureType Γ e₂ .real →
      HasPureType Γ (.le e₁ e₂) .bool

inductive HasProgType : Ctx → Prog → Ty → Eff → Prop where
  | tReturn {Γ e τ} :
      HasPureType Γ e τ →
      HasProgType Γ (.ret e) τ Eff.zero
  | tDist {Γ e₁ e₂ δ₀} :
      HasPureType Γ e₁ .pt →
      HasPureType Γ e₂ .pt →
      HasProgType Γ (.dist e₁ e₂) .real ⟨1, δ₀⟩
  | tLet {Γ x P₁ P₂ τ₁ τ₂ eff₁ eff₂} :
      HasProgType Γ P₁ τ₁ eff₁ →
      HasProgType (extendCtx Γ x τ₁) P₂ τ₂ eff₂ →
      HasProgType Γ (.let1 x P₁ P₂) τ₂ (Eff.add eff₁ eff₂)
  | tIf {Γ e P₁ P₂ τ eff₁ eff₂} :
      HasPureType Γ e .bool →
      HasProgType Γ P₁ τ eff₁ →
      HasProgType Γ P₂ τ eff₂ →
      HasProgType Γ (.ite e P₁ P₂) τ (Eff.max eff₁ eff₂)
  | tFold {Γ eS ez x s Pb τ qb δb n} :
      HasPureType Γ eS .setPt →
      HasPureType Γ ez τ →
      HasProgType (extendCtx (extendCtx Γ x .pt) s τ) Pb τ ⟨qb, δb⟩ →
      HasProgType Γ (.fold eS ez x s Pb) τ ⟨n * qb, (n : Rational) * δb⟩

def KCSpec (alpha beta : Rational) : Ty := .kc alpha beta

end TypedKCenter
