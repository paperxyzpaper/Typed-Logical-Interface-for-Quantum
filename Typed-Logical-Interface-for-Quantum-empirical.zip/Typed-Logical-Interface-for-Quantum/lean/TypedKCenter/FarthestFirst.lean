namespace TypedKCenter


import TypedKCenter.Syntax
import TypedKCenter.Typing
import TypedKCenter.Semantics
import TypedKCenter.Compilation

open Ty PureExpr Prog

def mindistMacro (v C : PureExpr) : Prog :=
  Prog.fold C (PureExpr.realLit 1000000) "x" "s"
    (Prog.let1 "d"
      (Prog.dist v (PureExpr.var "x"))
      (Prog.ret (PureExpr.min (PureExpr.var "s") (PureExpr.var "d"))))

def argmaxMindistMacro (V C : PureExpr) : Prog :=
  Prog.fold V (PureExpr.ptLit "dummy") "x" "s"
    (Prog.ret (PureExpr.var "x"))

def farthestFirstProgram (V : PureExpr) (start : PureExpr) : Prog :=
  Prog.ret (PureExpr.singletonSet start)

theorem typing_mindist_skeleton : True := by
  trivial

theorem typing_argmax_skeleton : True := by
  trivial

theorem typing_farthest_first_skeleton : True := by
  trivial

theorem approx_farthest_point_skeleton : True := by
  trivial

theorem ff_additive_bound_skeleton : True := by
  trivial

end TypedKCenter
