namespace TypedKCenter


inductive Ty where
  | pt
  | real
  | nat
  | bool
  | setPt
  | pair (τ₁ τ₂ : Ty)
  | kc (alpha beta : Rational)
  deriving Repr, DecidableEq

inductive PureExpr where
  | var : String → PureExpr
  | ptLit : String → PureExpr
  | realLit : Rational → PureExpr
  | natLit : Nat → PureExpr
  | boolLit : Bool → PureExpr
  | emptySet : PureExpr
  | singletonSet : PureExpr → PureExpr
  | finiteSet : List PureExpr → PureExpr
  | pair : PureExpr → PureExpr → PureExpr
  | fst : PureExpr → PureExpr
  | snd : PureExpr → PureExpr
  | mem : PureExpr → PureExpr → PureExpr
  | insert : PureExpr → PureExpr → PureExpr
  | min : PureExpr → PureExpr → PureExpr
  | max : PureExpr → PureExpr → PureExpr
  | le : PureExpr → PureExpr → PureExpr
  deriving Repr, DecidableEq

inductive Prog where
  | ret : PureExpr → Prog
  | dist : PureExpr → PureExpr → Prog
  | let1 : String → Prog → Prog → Prog
  | ite : PureExpr → Prog → Prog → Prog
  | fold : PureExpr → PureExpr → String → String → Prog → Prog
  deriving Repr, DecidableEq

abbrev Ctx := List (String × Ty)

def lookupCtx (Γ : Ctx) (x : String) : Option Ty :=
  match Γ with
  | [] => none
  | (y, τ) :: Γ' => if x = y then some τ else lookupCtx Γ' x

def extendCtx (Γ : Ctx) (x : String) (τ : Ty) : Ctx := (x, τ) :: Γ

end TypedKCenter
