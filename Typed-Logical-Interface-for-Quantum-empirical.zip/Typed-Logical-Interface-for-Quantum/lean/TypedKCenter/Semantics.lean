namespace TypedKCenter


import TypedKCenter.Syntax
import TypedKCenter.Typing

open Ty PureExpr Prog

inductive Value where
  | ptVal : String → Value
  | realVal : Rational → Value
  | natVal : Nat → Value
  | boolVal : Bool → Value
  | setVal : List Value → Value
  | pairVal : Value → Value → Value
  deriving Repr, DecidableEq

abbrev Env := List (String × Value)

def lookupEnv (ρ : Env) (x : String) : Option Value :=
  match ρ with
  | [] => none
  | (y, v) :: ρ' => if x = y then some v else lookupEnv ρ' x

def extendEnv (ρ : Env) (x : String) (v : Value) : Env := (x, v) :: ρ

abbrev TraceEntry := String × String × Rational
abbrev Trace := List TraceEntry

structure Oracle where
  dist : String → String → Rational

def GoodTrace (q : Nat) (ε : Rational) (π : Trace) (trueDist : String → String → Rational) : Prop :=
  π.length ≤ q ∧ ∀ (u v dhat), (u, v, dhat) ∈ π → |dhat - trueDist u v| ≤ ε

inductive EvalPure : Env → PureExpr → Value → Prop where
  | eVar {ρ x v} :
      lookupEnv ρ x = some v →
      EvalPure ρ (.var x) v
  | ePtLit {ρ p} :
      EvalPure ρ (.ptLit p) (.ptVal p)
  | eRealLit {ρ r} :
      EvalPure ρ (.realLit r) (.realVal r)
  | eNatLit {ρ n} :
      EvalPure ρ (.natLit n) (.natVal n)
  | eBoolLit {ρ b} :
      EvalPure ρ (.boolLit b) (.boolVal b)

inductive EvalProg : Env → Oracle → Prog → Value → Trace → Prop where
  | eReturn {ρ O e v} :
      EvalPure ρ e v →
      EvalProg ρ O (.ret e) v []
  | eDist {ρ O e₁ e₂ u v dhat} :
      EvalPure ρ e₁ (.ptVal u) →
      EvalPure ρ e₂ (.ptVal v) →
      dhat = O.dist u v →
      EvalProg ρ O (.dist e₁ e₂) (.realVal dhat) [(u, v, dhat)]
  | eLet {ρ O x P₁ P₂ v₁ v₂ π₁ π₂} :
      EvalProg ρ O P₁ v₁ π₁ →
      EvalProg (extendEnv ρ x v₁) O P₂ v₂ π₂ →
      EvalProg ρ O (.let1 x P₁ P₂) v₂ (π₁ ++ π₂)
  | eIfTrue {ρ O e P₁ P₂ v π} :
      EvalPure ρ e (.boolVal true) →
      EvalProg ρ O P₁ v π →
      EvalProg ρ O (.ite e P₁ P₂) v π
  | eIfFalse {ρ O e P₁ P₂ v π} :
      EvalPure ρ e (.boolVal false) →
      EvalProg ρ O P₂ v π →
      EvalProg ρ O (.ite e P₁ P₂) v π

end TypedKCenter
