namespace TypedKCenter


import TypedKCenter.Syntax
import TypedKCenter.Typing
import TypedKCenter.Semantics

open Prog

inductive TargetProg where
  | ret : PureExpr → TargetProg
  | apiDist : PureExpr → PureExpr → TargetProg
  | let1 : String → TargetProg → TargetProg → TargetProg
  | ite : PureExpr → TargetProg → TargetProg → TargetProg
  | fold : PureExpr → PureExpr → String → String → TargetProg → TargetProg
  deriving Repr, DecidableEq

def compile : Prog → TargetProg
  | .ret e => .ret e
  | .dist e₁ e₂ => .apiDist e₁ e₂
  | .let1 x P₁ P₂ => .let1 x (compile P₁) (compile P₂)
  | .ite e P₁ P₂ => .ite e (compile P₁) (compile P₂)
  | .fold eS ez x s Pb => .fold eS ez x s (compile Pb)

theorem compile_shape_preserved (P : Prog) : True := by
  trivial

end TypedKCenter
