import Lake
open Lake DSL

package "TypedKCenter" where

@[default_target]
lean_lib «TypedKCenter» where
